//enable lvgl port
#if 1
#ifndef LVGL_PORT_TOUCH_H
#define LVGL_PORT_TOUCH_H

//include
#include"lvgl/lvgl.h"
//#include"touch_driver.h"

//lvgl port touch init
void lvgl_port_touch_init();

#endif//#ifndef LVGL_PORT_TOUCH_H
#endif//#if 1
