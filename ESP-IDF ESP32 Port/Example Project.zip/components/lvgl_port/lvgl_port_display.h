//enable lvgl port
#if 1
#ifndef LVGL_PORT_DISPLAY_H
#define LVGL_PORT_DISPLAY_H

//include
#include"lvgl/lvgl.h"
//#include"screen_driver.h"

//lvgl port display init
void lvgl_port_display_init();

#endif//#ifndef LVGL_PORT_DISPLAY_H
#endif//#if 1
