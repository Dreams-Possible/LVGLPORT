//enable lvgl port
#if 1
#ifndef LVGL_PORT_H
#define LVGL_PORT_H

//include
#include"lvgl/lvgl.h"
//#include"screen_driver.h"

//lvgl port init
void lvgl_port_init();

#endif//#ifndef LVGL_PORT_H
#endif//#if 1
