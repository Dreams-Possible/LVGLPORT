#include<stdio.h>
#include"freertos/FreeRTOS.h"
#include"freertos/task.h"

#include"lvgl/lvgl.h"
#include"lvgl_port.h"

void app_main(void)
{
    //screen_init();

    //lvgl init
    lv_init();

    //lvgl port init
    lvgl_port_init();

    //ui_init();

    while(1)
    {
        lv_tick_inc(10);
        lv_task_handler();
        vTaskDelay(pdMS_TO_TICKS(10));
    }

}
